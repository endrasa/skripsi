import csv
import os
from models import Transaksi

DATA_PATH = os.path.join(os.path.dirname(__file__), '../data/transaksi.csv')

def tampilkan_laporan():
    transaksi_list = []
    if not os.path.exists(DATA_PATH):
        print("Data transaksi belum ada.")
        return

    with open(DATA_PATH, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            transaksi = Transaksi(
                row['Tanggal'],
                row['Nama Barang'],
                row['Jumlah'],
                row['Modal Satuan'],
                row['Harga Jual Satuan']
            )
            transaksi_list.append(transaksi)

    if not transaksi_list:
        print("Belum ada data transaksi.")
        return

    print("=== LAPORAN REKAP TRANSAKSI ===")
    print(f"{'Tanggal':<12} {'Barang':<20} {'Jml':>4} {'Modal':>10} {'Jual':>10} {'Untung/Rugi':>12}")
    print('-'*70)
    total_modal = total_jual = total_untung = 0
    for t in transaksi_list:
        print(f"{t.tanggal:<12} {t.nama_barang:<20} {t.jumlah:>4} {t.total_modal:>10.0f} {t.total_jual:>10.0f} {t.untung_rugi:>12.0f}")
        total_modal += t.total_modal
        total_jual += t.total_jual
        total_untung += t.untung_rugi
    print('-'*70)
    print(f"{'TOTAL':<36} {total_modal:>10.0f} {total_jual:>10.0f} {total_untung:>12.0f}")

if __name__ == "__main__":
    tampilkan_laporan()