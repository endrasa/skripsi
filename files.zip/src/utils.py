import csv
from models import Transaksi

def tambah_transaksi(file_csv, transaksi: Transaksi):
    """Menambah data transaksi ke file CSV."""
    # Jika file baru, tambahkan header
    try:
        with open(file_csv, 'r', newline='', encoding='utf-8') as f:
            pass
    except FileNotFoundError:
        with open(file_csv, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['Tanggal', 'Nama Barang', 'Jumlah', 'Modal Satuan', 'Harga Jual Satuan'])

    # Tambahkan data transaksi
    with open(file_csv, 'a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([
            transaksi.tanggal,
            transaksi.nama_barang,
            transaksi.jumlah,
            transaksi.modal_satuan,
            transaksi.harga_jual_satuan
        ])