import os
from models import Transaksi
from utils import tambah_transaksi

DATA_PATH = os.path.join(os.path.dirname(__file__), '../data/transaksi.csv')

def tambah_data():
    print("=== Input Data Transaksi Penjualan ===")
    tanggal = input("Tanggal (YYYY-MM-DD): ")
    nama = input("Nama Barang: ")
    jumlah = input("Jumlah: ")
    modal = input("Modal Satuan (harga beli per barang): ")
    jual = input("Harga Jual Satuan (harga jual per barang): ")
    transaksi = Transaksi(tanggal, nama, jumlah, modal, jual)
    tambah_transaksi(DATA_PATH, transaksi)
    print("Data transaksi berhasil ditambahkan!\n")

if __name__ == "__main__":
    tambah_data()