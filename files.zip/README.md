# Sistem Perhitungan Jualan (Untung & Rugi)

Aplikasi sederhana untuk mencatat transaksi penjualan, menghitung otomatis untung/rugi, dan menampilkan laporan rekap.

## Struktur Folder
- `src/` : kode Python utama
- `data/` : file data transaksi (CSV)
- `doc/` : dokumentasi

## Cara Menjalankan
1. Pastikan Python 3 sudah terinstall.
2. Masuk ke folder `src`, lalu jalankan:
   ```
   python main.py
   ```
   atau
   ```
   python laporan.py
   ```
3. Ikuti instruksi di terminal.